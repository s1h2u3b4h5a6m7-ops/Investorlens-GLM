# How to Upload InvestorLens to GitHub (For Non-Tech Users)

You have TWO options. Option 1 is easiest.

---

## OPTION 1: Use GitHub Desktop (RECOMMENDED)

### Step 1: Install GitHub Desktop
- Go to: https://desktop.github.com/
- Download and install (it's free, made by GitHub)

### Step 2: Create a new repo on GitHub
- Go to: https://github.com/new
- Repository name: `investorlens`
- Description: `Data-driven research infrastructure for Indian listed companies`
- Select: **Public** (gives free unlimited GitHub Actions)
- DO NOT check any "Initialize" boxes
- Click: **Create repository**

### Step 3: Clone the empty repo
- Open GitHub Desktop
- Click: **File → Clone repository**
- Find `investorlens` in the list
- Click: **Clone**
- Note where it saves (usually `Documents/GitHub/investorlens`)

### Step 4: Copy files
- Unzip `investorlens-github-ready.zip`
- Open the `investorlens-repo` folder
- Select ALL files (Ctrl+A on Windows, Cmd+A on Mac)
- Copy them (Ctrl+C / Cmd+C)
- Open the `investorlens` folder that GitHub Desktop created
- Paste everything there (Ctrl+V / Cmd+V)
- If asked to replace/merge, click YES

### Step 5: Commit and push
- Go back to GitHub Desktop
- You'll see files listed in "Changes" (left side)
- Type in "Summary" box: `Initial commit`
- Click: **Commit to main**
- Click: **Push origin** (blue button at top)
- Wait for upload to finish

### Step 6: Enable Actions
- Go to your repo on GitHub.com
- Click: **Settings**
- Click: **Actions** → **General** (left sidebar)
- Select: **Allow all actions**
- Under "Workflow permissions": select **Read and write permissions**
- Click: **Save**

### Step 7: Run the pipeline
- Click: **Actions** tab (top of repo)
- Click: **Daily Pipeline** (left sidebar)
- Click: **Run workflow** → **Run workflow**
- Click the running workflow to watch it fetch live data!

---

## OPTION 2: Command Line (if you have git)

```bash
unzip investorlens-github-ready.zip
cd investorlens-repo
git init
git add -A
git commit -m "Initial commit: InvestorLens"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/investorlens.git
git push -u origin main
```

Then do Steps 6-7 from Option 1.

---

## What happens after uploading?

1. **CI** runs automatically — tests all 613 tests
2. **Daily Pipeline** runs at 18:30 IST Mon-Sat:
   - Fetches live NSE/BSE/Yahoo/RBI/MOSPI data
   - Builds notes, canvases, web graph
   - Commits everything back to your repo
3. **Weekly Backfill** runs Sundays — 5-year price history

## To view the web graph locally:
```bash
cd web-graph
npm install
npm run dev
```
Open http://localhost:5173

## If the pipeline fails:
GitHub auto-creates an "Issue" telling you what went wrong.
