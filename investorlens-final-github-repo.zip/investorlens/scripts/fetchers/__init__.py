"""Marker file — fetchers package."""
